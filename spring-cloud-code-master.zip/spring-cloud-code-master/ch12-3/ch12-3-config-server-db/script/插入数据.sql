
INSERT INTO `spring-cloud`.`properties` (`ID`, `KEY`, `VALUE`, `APPLICATION`, `PROFILE`, `LABLE`) VALUES ('3', 'cn.springcloud.book.config', 'I am the mysql configuration file from dev environment.', 'config-info', 'dev', 'master');
INSERT INTO `spring-cloud`.`properties` (`ID`, `KEY`, `VALUE`, `APPLICATION`, `PROFILE`, `LABLE`) VALUES ('4', 'cn.springcloud.book.config', 'I am the mysql configuration file from test environment.', 'config-info', 'test', 'master');
INSERT INTO `spring-cloud`.`properties` (`ID`, `KEY`, `VALUE`, `APPLICATION`, `PROFILE`, `LABLE`) VALUES ('5', 'cn.springcloud.book.config', 'I am the mysql configuration file from prod environment.', 'config-info', 'prod', 'master');
