## Consul 服务调用方
这里只是一个简单的 demo, 演示客户端如何通过 consul 调用到服务端