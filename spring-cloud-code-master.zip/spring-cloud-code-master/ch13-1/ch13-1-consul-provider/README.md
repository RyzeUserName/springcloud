## Consul 服务提供方
这里只是一个简单的 demo, 演示服务端注册到 consul 并对外提供服务