package PACKAGE_NAME;

public class ConsulProviderTag1Application {
}
