package cn.springcloud.book.gateway;

public class ConsumerApplicationTests {

	public void contextLoads() {
	}

}
