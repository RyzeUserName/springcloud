package cn.springcloud.book.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SCGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(SCGatewayApplication.class, args);
	}
}
