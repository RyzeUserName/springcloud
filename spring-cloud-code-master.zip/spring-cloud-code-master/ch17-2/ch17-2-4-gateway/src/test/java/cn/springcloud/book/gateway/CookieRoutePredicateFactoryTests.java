package cn.springcloud.book.gateway;

public class CookieRoutePredicateFactoryTests {

	public void contextLoads() {
	}

}
