package cn.springcloud.book.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CH1737GatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(CH1737GatewayApplication.class, args);
	}
}
